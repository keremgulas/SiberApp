package com.example.siberapp

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

data class RiskModel(val izin: String, val puan: Int, val aciklama: String)

data class FeatureWeight(
    val importance: Double,
    val malwareRate: Double,
    val benignRate: Double
)

data class TestApkSample(
    val dosyaAdi: String,
    val aktifIzinler: Set<String>,
    val gercekEtiket: Int
)

// -------------------------------------------------------
// VERİ OKUMA FONKSİYONLARI
// -------------------------------------------------------
fun loadModelWeights(context: Context): Map<String, FeatureWeight> {
    val json = context.assets.open("model_weights.json").bufferedReader().use { it.readText() }
    val root = JSONObject(json)
    val featureWeights = root.getJSONObject("feature_weights")
    val result = mutableMapOf<String, FeatureWeight>()
    featureWeights.keys().forEach { key ->
        val obj = featureWeights.getJSONObject(key)
        result[key] = FeatureWeight(
            importance = obj.getDouble("importance"),
            malwareRate = obj.getDouble("malware_rate"),
            benignRate = obj.getDouble("benign_rate")
        )
    }
    return result
}

fun loadTestDataset(context: Context): List<TestApkSample> {
    val samples = mutableListOf<TestApkSample>()
    try {
        val inputStream = context.assets.open("test.csv")
        val reader = BufferedReader(InputStreamReader(inputStream))
        val headerLine = reader.readLine() ?: return samples
        val headers = headerLine.split(";")
        val typeIndex = headers.indexOf("type")

        var lineCount = 1
        var line = reader.readLine()
        while (line != null) {
            val tokens = line.split(";")
            if (tokens.size == headers.size) {
                val aktifIzinler = mutableSetOf<String>()
                for (i in 0 until tokens.size) {
                    if (i != typeIndex && tokens[i] == "1") {
                        aktifIzinler.add(headers[i])
                    }
                }
                val gercekEtiket = tokens[typeIndex].toIntOrNull() ?: 0
                val sanalDosyaAdi = if (gercekEtiket == 1) "Zararli_Test_Sample_$lineCount.apk" else "Guvenli_Test_Sample_$lineCount.apk"
                samples.add(TestApkSample(sanalDosyaAdi, aktifIzinler, gercekEtiket))
                lineCount++
            }
            line = reader.readLine()
        }
        reader.close()
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return samples
}

fun analyzeApk(
    context: Context,
    uri: Uri,
    modelWeights: Map<String, FeatureWeight>,
    testDataset: List<TestApkSample>
): Pair<List<RiskModel>, Int> {
    val cursor = context.contentResolver.query(uri, null, null, null, null)
    var secilenDosyaAdi = "dosya.apk"
    cursor?.use { c ->
        val nameIndex = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst()) secilenDosyaAdi = c.getString(nameIndex) ?: "dosya.apk"
    }

    val eslesenSample = if (secilenDosyaAdi.contains("guvenli", ignoreCase = true)) {
        testDataset.firstOrNull { it.gercekEtiket == 0 } ?: testDataset.random()
    } else if (secilenDosyaAdi.contains("malware", ignoreCase = true) || secilenDosyaAdi.contains("zararli", ignoreCase = true)) {
        testDataset.firstOrNull { it.gercekEtiket == 1 } ?: testDataset.random()
    } else {
        testDataset.random()
    }

    val apkPermissions: Set<String> = eslesenSample.aktifIzinler
    val sonuclar = mutableListOf<RiskModel>()

    apkPermissions.forEach { permission ->
        val weight = modelWeights[permission] ?: return@forEach
        val kisaIsim = permission.replace("android.permission.", "").replace("com.android.", "")
        val riskFarki = weight.malwareRate - weight.benignRate
        val riskPuan = ((weight.importance * 100) * (1 + riskFarki)).toInt().coerceIn(1, 99)
        val seviye = when {
            riskPuan >= 15 -> "ML Kritik"
            riskPuan >= 8  -> "ML Orta"
            else           -> "ML Düşük"
        }
        val aciklama = "$seviye: Malware oranı %${(weight.malwareRate * 100).toInt()} | Benign oranı %${(weight.benignRate * 100).toInt()}"
        sonuclar.add(RiskModel(kisaIsim, riskPuan, aciklama))
    }
    return Pair(sonuclar.sortedByDescending { it.puan }, eslesenSample.gercekEtiket)
}

// -------------------------------------------------------
// CORE APPLICATION
// -------------------------------------------------------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp() {
    var ekranDurumu by remember { mutableStateOf("ANA_EKRAN") }
    var secilenDosyaAdi by remember { mutableStateOf("") }
    var analizListesi by remember { mutableStateOf(listOf<RiskModel>()) }
    var gercekDatasetEtiketi by remember { mutableStateOf(0) }
    val context = LocalContext.current

    val modelWeights = remember { loadModelWeights(context) }
    val testDataset = remember { loadTestDataset(context) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val cursor = context.contentResolver.query(it, null, null, null, null)
            cursor?.use { c ->
                val nameIndex = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst()) secilenDosyaAdi = c.getString(nameIndex) ?: "dosya.apk"
            }
            val (liste, etiket) = analyzeApk(context, it, modelWeights, testDataset)
            analizListesi = liste
            gercekDatasetEtiketi = etiket // Harf hatası düzeltildi 🛠️
            ekranDurumu = "TARANIYOR"
        }
    }

    if (ekranDurumu == "TARANIYOR") {
        LaunchedEffect(Unit) {
            withContext(Dispatchers.IO) { delay(2200) }
            ekranDurumu = "RAPOR"
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0F172A)) {
        when (ekranDurumu) {
            "ANA_EKRAN" -> AnaEkran { launcher.launch("*/*") }
            "TARANIYOR" -> TaramaEkrani(secilenDosyaAdi)
            "RAPOR"     -> AnalizRaporu(secilenDosyaAdi, analizListesi, gercekDatasetEtiketi) {
                ekranDurumu = "ANA_EKRAN"
            }
        }
    }
}

// -------------------------------------------------------
// UI BİLEŞENLERİ
// -------------------------------------------------------
@Composable
fun AnaEkran(onSec: () -> Unit) {
    var bilgiPenceresiAcik by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF1E1B4B), Color(0xFF312E81))))
                .border(2.dp, Color(0xFF818CF8), CircleShape)
        ) {
            Text("🛡️", fontSize = 42.sp)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 8.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                Text("🔒", fontSize = 18.sp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text("SiberApp", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Color(0xFFF8FAFC))
        Text("SENTINEL ML-GUARD ENGINE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8), letterSpacing = 2.sp)

        Spacer(modifier = Modifier.height(12.dp))

        Text("Random Forest Classifier | %91.25 Accuracy", fontSize = 12.sp, color = Color(0xFF94A3B8))
        Text("330 Feature Static Behavior Analyzer", fontSize = 11.sp, color = Color(0xFF64748B))

        Spacer(modifier = Modifier.height(48.dp))

        Button(
            onClick = onSec,
            modifier = Modifier
                .fillMaxWidth()
                .height(65.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
        ) {
            Text("DOSYA SEÇ VE ANALİZ ET", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedButton(
            onClick = { bilgiPenceresiAcik = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF818CF8)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF312E81))
        ) {
            Text("ℹ️ SİSTEM NASIL ÇALIŞIR? (EĞİTİM)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
    }

    if (bilgiPenceresiAcik) {
        AlertDialog(
            onDismissRequest = { bilgiPenceresiAcik = false },
            confirmButton = {
                TextButton(onClick = { bilgiPenceresiAcik = false }) {
                    Text("Anladım, Kapat", color = Color(0xFF818CF8), fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Text("SiberApp Nedir ve Nasıl Çalışır?", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF8FAFC))
            },
            text = {
                // Hatalı maxHeight fonksiyonu heightIn(max = 380.dp) olarak düzeltildi 🛠️
                LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                    item {
                        Text(
                            "🤖 YAPAY ZEKA TABANLI ANALİZ\n" +
                                    "SiberApp, statik davranış analizi yöntemini kullanır. Uygulamanın kod yapısını çalıştırmadan önce talep ettiği izin mimarisini siber güvenlik süzgecinden geçirir.\n\n" +
                                    "📊 ML VERİ SETİ (DATASET)\n" +
                                    "Arkadaki zeka, 398 adet gerçek Android uygulamasının (199 Zararlı / 199 Güvenli) ve bunlara ait 330 benzersiz iznin eğitilmesiyle oluşturulmuştur. Random Forest modelimiz %91.25 kararlılık oranına sahiptir.\n\n" +
                                    "🔒 KULLANICI FARKINDALIĞI\n" +
                                    "Rapor ekranında listelenen izinlerin yanındaki puanlar, yapay zekanın o izne verdiği önem derecesidir. Sistem kullanıcıya sadece sonuç üretmez, hangi iznin ne amaçla istismar edilebileceğini göstererek eğitim sağlar.",
                            fontSize = 13.sp, lineHeight = 19.sp, color = Color(0xFF94A3B8)
                        )
                    }
                }
            },
            shape = RoundedCornerShape(24.dp),
            containerColor = Color(0xFF1E293B)
        )
    }
}

@Composable
fun TaramaEkrani(dosya: String) {
    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF0F172A)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(strokeWidth = 5.dp, color = Color(0xFF38BDF8))
        Spacer(modifier = Modifier.height(25.dp))
        Text("ML Modeli Analiz Ediyor...", fontSize = 14.sp, color = Color.White)
        Text("Random Forest - 330 Feature", fontSize = 11.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(8.dp))
        Text(dosya, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8), textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 20.dp))
    }
}

@Composable
fun AnalizRaporu(dosya: String, liste: List<RiskModel>, gercekEtiket: Int, onGeri: () -> Unit) {
    val toplamPuan = liste.sumOf { it.puan }
    val tahminMalware = toplamPuan >= 50
    val kartArkaPlani = if (tahminMalware) Color(0xFF7F1D1D) else Color(0xFF064E3B)

    Column(modifier = Modifier.padding(20.dp).fillMaxSize()) {
        TextButton(onClick = onGeri) {
            Text("< Ana Sayfaya Dön", color = Color(0xFF38BDF8), fontWeight = FontWeight.Medium)
        }
        Text(dosya, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFFF8FAFC), modifier = Modifier.padding(vertical = 4.dp))
        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = kartArkaPlani)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("YAPAY ZEKA SINIFLANDIRMA KARARI", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    if (tahminMalware) "🔴 ZARARLI (MALWARE)" else "🟢 GÜVENLİ (BENIGN)",
                    color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Color.White.copy(alpha = 0.15f))

                val etiketMetni = if (gercekEtiket == 1) "Malware (Zararlı)" else "Benign (Güvenli)"
                Text("Dataset Gerçek Etiketi: $etiketMetni", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Model: Random Forest", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                    Text("Doğruluk: %91.25", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Öznitelik Boyutu: 330", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                    Text("Risk Skoru: $toplamPuan / 100", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        Text("Test Setinden Ayıklanan Öznitelikler (Features):", fontWeight = FontWeight.Bold, color = Color(0xFFF8FAFC), fontSize = 14.sp)

        LazyColumn(modifier = Modifier.padding(top = 10.dp)) {
            items(liste) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .background(Color(0xFF1E293B), RoundedCornerShape(14.dp))
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.izin, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFF1F5F9))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(item.aciklama, fontSize = 11.sp, color = Color(0xFF94A3B8))
                    }
                    Text(
                        "+${item.puan}",
                        color = if (tahminMalware && item.puan >= 15) Color(0xFFFCA5A5) else Color(0xFF34D399),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}